@echo off
cd /d "%~dp0"
start "" wscript.exe "%~dp0BASLAT_GIZLI.vbs"
exit /b
