@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"$p=Get-CimInstance Win32_Process ^| Where-Object { $_.Name -match 'python|py' -and $_.CommandLine -match 'app\.py' }; foreach($x in $p){ Write-Host ('Kapatiliyor PID '+$x.ProcessId); Stop-Process -Id $x.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 1"
echo.
echo 8788 kontrol:
netstat -ano | findstr :8788
echo.
echo Yukarida LISTENING yoksa tamamen kapanmistir.
pause
