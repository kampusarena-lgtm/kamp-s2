﻿param(
    [Parameter(Mandatory=$true)][string]$Day,
    [string]$LiveDb = "C:\Program Files (x86)\Pan Group\PanCafe Pro Server\Data\USDB.DAT",
    [string]$EmbedDir = "C:\FirebirdEmbed",
    [string]$RuntimeDir = "C:\KampusArenaMuhasebe\runtime\pancafe"
)

$ErrorActionPreference = "Stop"

function Out-JsonError([string]$Message) {
    [pscustomobject]@{ ok=$false; error=$Message; version="V10.5.0" } | ConvertTo-Json -Compress
    exit 1
}

try {
    $dayDate = [datetime]::ParseExact($Day, "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture)
    $start = $dayDate.Date.AddHours(9)
    $end = $start.AddDays(1)

    $isql = Join-Path $EmbedDir "isql.exe"
    $fbclient = Join-Path $EmbedDir "fbclient.dll"
    if (-not (Test-Path -LiteralPath $LiveDb)) { throw "PanCafe USDB.DAT bulunamadi: $LiveDb" }
    if (-not (Test-Path -LiteralPath $isql)) { throw "Firebird isql.exe bulunamadi: $isql" }
    if (-not (Test-Path -LiteralPath $fbclient)) { throw "Firebird fbclient.dll bulunamadi: $fbclient" }

    New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
    $tag = "{0}_{1}" -f $PID, ([guid]::NewGuid().ToString("N"))
    $snapshot = Join-Path $RuntimeDir ("USDB_SNAPSHOT_{0}.DAT" -f $tag)

    try {
        # Canli PanCafe DB'ye SQL baglantisi/yazma yok. Sadece paylasimli salt-okuma snapshot.
        $share = [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
        $src = [System.IO.File]::Open($LiveDb, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, $share)
        try {
            $dst = [System.IO.File]::Open($snapshot, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
            try {
                $src.CopyTo($dst)
                $dst.Flush()
            }
            finally { $dst.Dispose() }
        }
        finally { $src.Dispose() }

        $snapInfo = Get-Item -LiteralPath $snapshot
        if ($snapInfo.Length -lt 1MB) { throw "PanCafe snapshot kopyasi gecersiz veya eksik." }

        $s = $start.ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture)
        $e = $end.ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture)

        # PanCafe GENEL TOPLAM:
        # GELIRGIDER=0 gelir; GELIRGIDER=1 PanCafe raporunda toplamdan dusulen hareket (iskonto gibi).
        # V10.5.0: stdin ASCII'ye zorlanir. UTF-8 BOM / bozuk karakter sorunu engellenir.
        # QUIT komutu gonderilmez; SELECT bittikten sonra stdin kapatilir ve isql EOF ile cikar.
        $sql = "SET LIST ON;`r`n" +
               "SELECT CAST(COALESCE(SUM(CASE WHEN GELIRGIDER = 0 THEN PRICE ELSE -PRICE END), 0) AS DECIMAL(18,2)) AS GENEL_TOPLAM`r`n" +
               "FROM KASAHAR`r`n" +
               "WHERE TARIH >= TIMESTAMP '$s'`r`n" +
               "  AND TARIH <  TIMESTAMP '$e';`r`n"

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $isql
        $psi.WorkingDirectory = $EmbedDir
        $psi.Arguments = "-user SYSDBA -password masterkey `"$snapshot`""
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        try { $psi.StandardInputEncoding = [System.Text.Encoding]::ASCII } catch {}
        try { $psi.StandardOutputEncoding = [System.Text.Encoding]::Default } catch {}
        try { $psi.StandardErrorEncoding = [System.Text.Encoding]::Default } catch {}

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        if (-not $proc.Start()) { throw "isql.exe baslatilamadi." }

        # WriteLine yerine ASCII StreamWriter acikca kullanilir; BOM yazilmaz.
        $ascii = New-Object System.Text.ASCIIEncoding
        $writer = New-Object System.IO.StreamWriter($proc.StandardInput.BaseStream, $ascii, 4096, $true)
        $writer.NewLine = "`r`n"
        $writer.Write($sql)
        $writer.Flush()
        $writer.Dispose()
        $proc.StandardInput.Close()

        $stdout = $proc.StandardOutput.ReadToEnd()
        $stderr = $proc.StandardError.ReadToEnd()
        $proc.WaitForExit()
        $exitCode = $proc.ExitCode
        $proc.Dispose()

        $output = (($stdout + "`r`n" + $stderr).Trim())
        $flat = ($output -replace "\r?\n", " | ").Trim()

        # Once sonucu parse et. Sonuc cikmissa sorgu calismistir.
        $m = [regex]::Match(
            $output,
            'GENEL_TOPLAM\s+(-?[0-9]+(?:[\.,][0-9]+)?)',
            [Text.RegularExpressions.RegexOptions]::IgnoreCase
        )

        if (-not $m.Success) {
            throw ("GENEL_TOPLAM ciktida bulunamadi. Firebird cikisi (exit=$exitCode): " + $flat)
        }

        $number = $m.Groups[1].Value.Replace(',', '.')
        $total = [double]::Parse($number, [Globalization.CultureInfo]::InvariantCulture)

        # Gercek sorgu hatalarinda sonuc olsa bile basarisiz say.
        # Eski 10.4.2'de gorulen BOM kaynakli 'Token unknown line 1 column 1' burada olusmamalidir.
        $fatal = $output -match "unavailable database|I/O error|cannot attach|Your user name and password are not defined|Table unknown|Column unknown|arithmetic exception"
        if ($fatal) {
            throw ("Firebird sorgu hatasi (exit=$exitCode): " + $flat)
        }

        [pscustomobject]@{
            ok = $true
            day = $Day
            start = $s
            end = $e
            total = [math]::Round($total, 2)
            source = "PanCafe KASAHAR / GENEL TOPLAM"
            snapshot_bytes = $snapInfo.Length
            isql_exit = $exitCode
            version = "V10.5.0"
        } | ConvertTo-Json -Compress
    }
    finally {
        Remove-Item -LiteralPath $snapshot -Force -ErrorAction SilentlyContinue
    }
}
catch {
    Out-JsonError $_.Exception.Message
}
