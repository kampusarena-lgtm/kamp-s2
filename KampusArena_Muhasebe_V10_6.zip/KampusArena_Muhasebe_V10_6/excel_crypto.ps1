﻿param(
    [Parameter(Mandatory=$true)][ValidateSet("Decrypt","Encrypt","PrepareAndEncrypt")][string]$Mode,
    [Parameter(Mandatory=$true)][string]$InputPath,
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"
$password = $env:KGA_EXCEL_PASSWORD
if ([string]::IsNullOrWhiteSpace($password)) { throw "Excel parolası boş." }
$excel = $null
$book = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false

    if ($Mode -eq "Decrypt") {
        if ([string]::IsNullOrWhiteSpace($OutputPath)) { throw "OutputPath gerekli." }
        $book = $excel.Workbooks.Open($InputPath, 0, $false, 5, $password)
        if (-not $book.HasPassword) { throw "Ana Excel dosyası parola korumalı değil. KURULUM.bat ile şifreleyin." }
        $book.SaveAs($OutputPath, 51, "")
    }
    elseif ($Mode -eq "Encrypt") {
        if ([string]::IsNullOrWhiteSpace($OutputPath)) { throw "OutputPath gerekli." }
        $book = $excel.Workbooks.Open($InputPath, 0, $false)
        $book.SaveAs($OutputPath, 51, $password)
    }
    elseif ($Mode -eq "PrepareAndEncrypt") {
        if ([string]::IsNullOrWhiteSpace($OutputPath)) { throw "OutputPath gerekli." }
        $book = $excel.Workbooks.Open($InputPath, 0, $false)
        try {
            $settings = $book.Worksheets.Item("AYARLAR")
            $settings.Range("A4").Value2 = "Excel Şifresi"
            $settings.Range("B4").Value2 = "DOSYA PAROLASI BU EXCEL İÇİNDE SAKLANMAZ"
            [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($settings)
        } catch { }
        $book.SaveAs($OutputPath, 51, $password)
    }
    $book.Close($false)
    try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book) } catch {}
    $book = $null
}
finally {
    if ($book -ne $null) {
        try { $book.Close($false) } catch {}
        try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book) } catch {}
    }
    if ($excel -ne $null) { try { $excel.Quit() } catch {} }
    if ($excel -ne $null) { try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel) } catch {} }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}
