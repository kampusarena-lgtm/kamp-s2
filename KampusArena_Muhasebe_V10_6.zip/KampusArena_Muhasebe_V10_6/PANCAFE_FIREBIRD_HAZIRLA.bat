@echo off
setlocal
chcp 65001 >nul

set "EMBED=C:\FirebirdEmbed"
set "FULL=C:\FirebirdTest\bin\isql.exe"

if not exist "%EMBED%" mkdir "%EMBED%"

if not exist "%EMBED%\isql.exe" (
    if exist "%FULL%" (
        copy /y "%FULL%" "%EMBED%\isql.exe" >nul
    )
)

if not exist "%EMBED%\fbclient.dll" (
    if exist "%EMBED%\fbembed.dll" (
        copy /y "%EMBED%\fbembed.dll" "%EMBED%\fbclient.dll" >nul
    )
)

set "OK=1"
if not exist "%EMBED%\isql.exe" set "OK=0"
if not exist "%EMBED%\fbembed.dll" set "OK=0"
if not exist "%EMBED%\fbclient.dll" set "OK=0"
if not exist "%EMBED%\firebird.msg" set "OK=0"

if "%OK%"=="1" (
    echo [OK] PanCafe Firebird okuma ortami hazir: C:\FirebirdEmbed
    exit /b 0
)

echo.
echo [UYARI] PanCafe otomatik GENEL TOPLAM icin Firebird dosyalari eksik.
echo Gerekli:
echo   C:\FirebirdEmbed\isql.exe
echo   C:\FirebirdEmbed\fbembed.dll
echo   C:\FirebirdEmbed\fbclient.dll
echo   C:\FirebirdEmbed\firebird.msg
echo.
echo FIREBIRD_KURULUM_NOTU.txt dosyasini takip edin.
exit /b 2
