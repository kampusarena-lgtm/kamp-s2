Option Explicit
Dim fso, sh, base, worker
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

base = fso.GetParentFolderName(WScript.ScriptFullName)
worker = base & "\BASLAT_ARKAPLAN.bat"

If Not fso.FileExists(worker) Then
    MsgBox "BASLAT_ARKAPLAN.bat bulunamadi.", 16, "Kampus Arena Muhasebe"
    WScript.Quit 1
End If

sh.Run Chr(34) & worker & Chr(34), 0, False
WScript.Sleep 1800
sh.Run "http://127.0.0.1:8788", 1, False
