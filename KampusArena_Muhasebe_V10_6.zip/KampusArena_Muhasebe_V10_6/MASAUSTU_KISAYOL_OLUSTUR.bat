@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0MASAUSTU_KISAYOL_OLUSTUR.ps1"
echo.
pause
