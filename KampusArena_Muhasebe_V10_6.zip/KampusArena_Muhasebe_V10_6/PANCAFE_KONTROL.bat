@echo off
chcp 65001 >nul
echo KAMPUS ARENA - PANCAFE OTOMATIK OKUMA KONTROLU
echo.

set "OK=1"

if exist "C:\Program Files (x86)\Pan Group\PanCafe Pro Server\Data\USDB.DAT" (
  echo [OK] PanCafe DB bulundu.
) else (
  echo [HATA] PanCafe DB bulunamadi:
  echo C:\Program Files (x86)\Pan Group\PanCafe Pro Server\Data\USDB.DAT
  set "OK=0"
)

call "%~dp0PANCAFE_FIREBIRD_HAZIRLA.bat"
if errorlevel 1 set "OK=0"

echo.
if "%OK%"=="1" (
  echo PANCAFE OTOMATIK GENEL TOPLAM ICIN ORTAM HAZIR.
  echo Test icin PANCAFE_TEST.bat calistirin.
) else (
  echo PANCAFE OTOMATIK OKUMA HENUZ HAZIR DEGIL.
)
echo.
pause
