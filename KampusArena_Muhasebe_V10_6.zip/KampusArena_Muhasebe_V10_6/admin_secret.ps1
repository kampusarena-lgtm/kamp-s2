﻿param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("Protect","Unprotect")]
    [string]$Mode,

    [Parameter(Mandatory=$true)]
    [string]$Path
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Security

if ($Mode -eq "Protect") {
    $plain = $env:KGA_EXCEL_PASSWORD
    if ([string]::IsNullOrEmpty($plain)) { throw "Excel ana şifresi boş." }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($plain)
    $protected = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    $b64 = [Convert]::ToBase64String($protected)
    [System.IO.File]::WriteAllText($Path, $b64, [System.Text.Encoding]::UTF8)
    exit 0
}

if (!(Test-Path $Path)) { throw "Yönetici Excel anahtar dosyası bulunamadı." }
$b64 = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8).Trim()
$protected = [Convert]::FromBase64String($b64)
$bytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
    $protected, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
)
$plain = [System.Text.Encoding]::UTF8.GetString($bytes)
[Console]::Out.Write($plain)
