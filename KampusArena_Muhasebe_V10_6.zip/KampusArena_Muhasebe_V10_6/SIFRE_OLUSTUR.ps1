﻿$ErrorActionPreference = "Stop"
$base = $PSScriptRoot
$template = Join-Path $base "KampusArena_Muhasebe_SABLON.kga"
$master = Join-Path $base "KampusArena_Muhasebe.xlsx"
$crypto = Join-Path $base "excel_crypto.ps1"
$secret = Join-Path $base "admin_secret.ps1"
$secretFile = Join-Path $base "admin_excel_secret.dat"

if (Test-Path $master) {
    Write-Host "Şifreli ana Excel zaten mevcut: $master" -ForegroundColor Yellow
    exit 0
}
if (!(Test-Path $template)) { throw "Şablon bulunamadı: $template" }

function Read-PlainSecure([string]$Prompt) {
    $s = Read-Host $Prompt -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

$p1 = Read-PlainSecure "Yeni Excel şifresini gir (4-15 karakter)"
$p2 = Read-PlainSecure "Şifreyi tekrar gir"
if ($p1 -ne $p2) { throw "Şifreler aynı değil." }
if ($p1.Length -lt 4 -or $p1.Length -gt 15) { throw "Şifre 4-15 karakter olmalı." }

$temp = Join-Path $env:TEMP ("KGA_V10_SETUP_" + [guid]::NewGuid().ToString("N") + ".xlsx")
Copy-Item $template $temp -Force
try {
    $env:KGA_EXCEL_PASSWORD = $p1
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $crypto -Mode PrepareAndEncrypt -InputPath $temp -OutputPath $master
    if ($LASTEXITCODE -ne 0) { throw "Excel şifreleme başarısız." }

    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $secret -Mode Protect -Path $secretFile
    if ($LASTEXITCODE -ne 0) { throw "Excel şifresinin Windows güvenli alanına kaydı başarısız." }

    Write-Host ""
    Write-Host "Excel şifresi oluşturuldu ve Windows DPAPI ile güvenli şekilde kaydedildi." -ForegroundColor Green
    Write-Host "Panel işlemleri artık SQLite üzerinden çalışır; Excel arka planda otomatik yenilenir." -ForegroundColor Green
}
finally {
    Remove-Item Env:KGA_EXCEL_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item $temp -Force -ErrorAction SilentlyContinue
    $p1 = $null; $p2 = $null
}
