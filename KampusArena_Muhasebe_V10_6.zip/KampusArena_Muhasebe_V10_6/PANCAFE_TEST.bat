@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo KAMPUS ARENA - PANCAFE GENEL TOPLAM TESTI V10.6
echo Muhasebe gunu: 09:00 - ertesi gun 09:00
echo.
set /p DAY=Tarih girin (Ornek 2026-10-04): 
if "%DAY%"=="" goto :eof
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pancafe_total.ps1" -Day "%DAY%" -LiveDb "C:\Program Files (x86)\Pan Group\PanCafe Pro Server\Data\USDB.DAT" -EmbedDir "C:\FirebirdEmbed" -RuntimeDir "%~dp0runtime\pancafe"
echo.
pause
