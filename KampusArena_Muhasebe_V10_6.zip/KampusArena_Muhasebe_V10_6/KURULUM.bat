@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Kampus Arena Muhasebe V10.6 - Temiz Kurulum

echo ==================================================
echo   KAMPUS ARENA MUHASEBE V10.6 - TEMIZ KURULUM
echo ==================================================
echo.

if exist "KampusArena_Muhasebe.db" (
  echo HATA: Bu klasorde mevcut SQLite veritabani var.
  echo Temiz kurulum icin BOS bir klasor kullanin.
  pause
  exit /b 1
)
if exist "KampusArena_Muhasebe.xlsx" (
  echo HATA: Bu klasorde mevcut muhasebe Excel dosyasi var.
  echo Temiz kurulum icin BOS bir klasor kullanin.
  pause
  exit /b 1
)
if exist "admin_excel_secret.dat" (
  echo HATA: Bu klasorde eski Excel anahtar dosyasi var.
  echo Temiz kurulum icin BOS bir klasor kullanin.
  pause
  exit /b 1
)

where py >nul 2>nul
if errorlevel 1 (
  echo HATA: Python bulunamadi.
  echo Python 3 kurulu olmali ve "py" komutu calismali.
  pause
  exit /b 1
)

echo [1/5] Python paketleri kuruluyor...
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo HATA: Python paket kurulumu basarisiz.
  pause
  exit /b 1
)

echo.
echo [2/5] Uygulama klasorleri hazirlaniyor...
if not exist "runtime" mkdir "runtime"
if not exist "runtime\pancafe" mkdir "runtime\pancafe"
if not exist "backups" mkdir "backups"

echo.
echo [3/5] Sifreli Excel yedegi hazirlaniyor...
echo NOT: Microsoft Excel masaustu programi kurulu olmalidir.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SIFRE_OLUSTUR.ps1"
if errorlevel 1 (
  echo HATA: Excel sifreleme/anahtar olusturma basarisiz.
  pause
  exit /b 1
)

echo.
echo [4/5] PanCafe otomatik GENEL TOPLAM ortami kontrol ediliyor...
call "%~dp0PANCAFE_FIREBIRD_HAZIRLA.bat"
if errorlevel 1 (
  echo [UYARI] Muhasebe paneli kurulacak, ancak PanCafe otomatik okuma icin
  echo FIREBIRD_KURULUM_NOTU.txt dosyasindaki adimlari tamamlayin.
)

echo.
echo [5/5] Masaustu kisayolu olusturuluyor...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0MASAUSTU_KISAYOL_OLUSTUR.ps1"
if errorlevel 1 (
  echo [UYARI] Masaustu kisayolu olusturulamadi. BASLAT.bat yine kullanilabilir.
)

echo.
echo ==================================================
echo   V10.6 KURULUM TAMAMLANDI
echo ==================================================
echo Ana veri: SQLite
echo Excel: sifreli otomatik senkron/yedek
echo Muhasebe gunu: 09:00 - ertesi gun 09:00
echo PanCafe: yalniz GENEL TOPLAM otomatik okunur
echo Sahsi Kart: odeme alana kadar gider degil, ortak alacagidir
echo CMD: normal baslatmada gizlidir
echo.
echo Baslatmak icin masaustundeki "Kampus Arena Muhasebe" kisayolunu
echo veya BASLAT.bat dosyasini kullanin.
echo.
pause
