﻿KAMPÜS ARENA MUHASEBE V10.6 — İLK KULLANIM

Bu paket temiz kurulum içindir. Test hesabı, test işlemi, eski veritabanı,
eski Excel parolası ve oturum anahtarı pakete eklenmedi.
Gönderdiğiniz orijinal RAR dosyası değiştirilmedi.

1) ZIP'i yeni, boş bir klasöre çıkarın. Örnek: C:\KampusArenaMuhasebe
2) Windows'ta Python 3.9 veya üzeri ve masaüstü Microsoft Excel kurulu olmalı.
3) KURULUM.bat dosyasını çalıştırın. Excel yedek şifrenizi siz belirleyin.
4) Kurulumdan sonra BASLAT.bat ile programı açın.
5) Aynı bilgisayarda http://127.0.0.1:8788 adresinden Yönetici Girişi'ne girin.
6) Ana yönetici hesabınızı oluşturun; panel şifresi en az 8 karakter olmalı.
7) Ayarlar'dan personeli, aylık maaşı ve varsayılan vardiyayı ekleyin.
8) İşlem girişi ekranından kasa, gider ve veresiye kayıtlarına başlayın.

PANELİN KULLANIMI
- Sol menüden kasa, gider, personel, ortaklar ve raporlara erişin.
- İşlem girişi ekranında personeli seçin; işlem türünü sekmeden belirleyin.
- Yönetici giriş yaptıysa işlemler yönetici adına kaydedilir.
- Kasa ön izlemesi kaydetmeden önce toplamı gösterir.
- Her muhasebe günü için yalnız bir aktif kasa kaydı oluşturulabilir.
- Muhasebe günü 09:00'da başlar ve ertesi gün 09:00'da biter.
- Yeni gider ve veresiye tutarları pozitif olmalı; kasa alanları sıfır olabilir.
- Maaş değişikliği mevcut muhasebe ayından itibaren uygulanır.
- Personel pasife alındığında geçmiş kayıtları raporlarda görünmeye devam eder.
- Şahsi kart alımı mevcut nakit esaslı işleyişi korur: önce ortak alacağı,
  ortağa nakit ödeme yapıldıkça ilgili kategoride gider oluşur.
- Veresiye kayıtlarını ve günlük kasa kalemlerini tutarlı girin;
  veresiye hareketi kasa kalemlerini otomatik değiştirmez.

PANCAFE VE EXCEL
- PanCafe GENEL TOPLAM okuma araçları pakette bulunuyor.
- PanCafe/Firebird için FIREBIRD_KURULUM_NOTU.txt dosyasını izleyin.
- PANCAFE_KONTROL.bat ve PANCAFE_TEST.bat ile kendi bilgisayarınızda kontrol edin.
- Excel yedek şifresi ve panel şifresi ayrıdır.
- SQLite ana veridir; otomatik Excel kopyası Windows/Excel üzerinden şifrelenir.
- PanCafe toplamı gün tamamlandıktan sonra alınır; gün içi ön izleme değildir.

DOSYALAR VE YEDEK
- KampusArena_Muhasebe.db: işletme verileri. Silmeyin.
- admin_excel_secret.dat: sizin Windows hesabınıza bağlı Excel anahtarı.
- runtime/session.key: kurulumda otomatik oluşan oturum anahtarı. Paylaşmayın.
- backups: otomatik yedekler.
- Program kapalıyken tüm klasörün ayrıca yedeğini alın.

BU SÜRÜMDE DÜZELTİLENLER
- Eşzamanlı maaş ve yemek ödemelerinde çift kayıt engellendi.
- Ödeme ve bağlı gider aynı veritabanı işlemi içinde oluşturulur;
  gider oluşturma başarısızsa ödeme de geri alınır.
- Geçersiz, negatif ve sonlu olmayan tutarlar reddedilir.
- Aktif günlük kasa tekilliği veritabanında korunur.
- Kasa tarihi değiştiğinde eski günün PanCafe toplamı taşınmaz.
- Kurulum başına rastgele, kalıcı oturum anahtarı oluşturulur.
- Ana yönetici yetkisi veritabanından doğrulanır; POST formları CSRF korumalıdır.
- İlk yönetici hesabı yalnız yerel bilgisayardan oluşturulabilir.
- Geçmiş personel ve aylık maaş tabanı korunur.
- Gelecek güne finansal giriş ve kilitli geçmiş güne personel mesaisi engellenir.
- Excel'e girilen açıklamalar formül olarak çalıştırılmaz, metin olarak yazılır.
- Telefon uyumlu yan menü, giriş sekmeleri, kasa ön izlemesi ve ilk kullanım
  yönlendirmesi eklendi. Çift tıklamada formun tekrar gönderimi engellenir.

KONTROL SONUÇLARI
- 13 otomatik muhasebe/güvenlik testi geçti.
- 14 sayfa, şablonlar ve Excel dışa aktarması kontrol edildi.
- Masaüstü 1440px ve telefon 390px tarayıcı kontrolleri geçti.
- İlk hesap, personel ekleme, gider kaydı, sekmeler, koşullu alanlar,
  klavye kullanımı, mobil menü ve sayfa taşması kontrol edildi.
- Tarayıcı JavaScript hatası görülmedi.
- Windows PowerShell/Excel şifrelemesi ve gerçek PanCafe/Firebird bağlantısı
  bu Linux ortamında çalıştırılamadı; Windows'ta doğrulanmalıdır.

OTOMATİK KONTROLÜ ÇALIŞTIRMA
Python paketleri kurulduktan sonra: py tests\test_application.py
Testler ayrı geçici kopyada çalışır; işletme verilerine yazmaz.

SORUN GİDERME
BASLAT_KONSOL.bat hata mesajlarını gösterir.
runtime\server_console.log ve Yönetim > Sistem kayıtları bölümünü inceleyin.
Bu yazılımın personel ekranı personel adı seçimiyle çalışır;
kişiye özel personel giriş şifresi bu sürümde eklenmedi.

MEVCUT KURULUMA AKTARIM
Bu paket kullanılmamış program için hazırlandı. İleride var olan kurulumun
üzerine dosya güncellerseniz önce programı kapatıp tam klasör yedeği alın;
veritabanı, Excel, anahtarlar ve backups dosyalarını koruyun.
Mevcut kurulumda KURULUM.bat çalıştırmayın. Bir günde birden fazla aktif kasa
kaydı varsa yükseltme otomatik silmek yerine durup uyarı verir.
