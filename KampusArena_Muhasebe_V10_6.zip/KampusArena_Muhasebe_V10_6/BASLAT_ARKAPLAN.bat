@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "runtime" mkdir "runtime"
py -u app.py >> "runtime\server_console.log" 2>&1
