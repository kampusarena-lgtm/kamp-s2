@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Kampus Arena Muhasebe V10.6 - KONSOL
echo KAMPUS ARENA MUHASEBE V10.6 - KONSOL MODU
echo Bu pencere sadece hata ayiklama icindir.
echo.
py -u app.py
pause
