﻿$ErrorActionPreference = "Stop"
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$link = Join-Path $desktop "Kampus Arena Muhasebe.lnk"

$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut($link)
$s.TargetPath = "$env:WINDIR\System32\wscript.exe"
$s.Arguments = '"' + (Join-Path $base "BASLAT_GIZLI.vbs") + '"'
$s.WorkingDirectory = $base
$s.Description = "Kampus Arena Muhasebe - Gizli Baslat"
$s.Save()

Write-Host "Masaustu kisayolu olusturuldu: $link"
