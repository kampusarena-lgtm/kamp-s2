﻿param([string]$Target)
$ErrorActionPreference = "Stop"
$base = $PSScriptRoot
$backup = $null
try {
    if ([string]::IsNullOrWhiteSpace($Target)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = "Mevcut muhasebe programinizin klasorunu secin (app.py ve KampusArena_Muhasebe.db bulunan klasor)."
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
        $Target = $dialog.SelectedPath
        $dialog.Dispose()
    }
    $Target = [IO.Path]::GetFullPath($Target)
    if (!(Test-Path -LiteralPath (Join-Path $Target 'app.py')) -or !(Test-Path -LiteralPath (Join-Path $Target 'KampusArena_Muhasebe.db'))) {
        throw "Secilen klasor mevcut muhasebe kurulumu degil. app.py ve KampusArena_Muhasebe.db bulunmali."
    }
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $client.Connect('127.0.0.1',8788)
        $running = $true
    } catch { $running = $false }
    finally { $client.Dispose() }
    if ($running) { throw "Muhasebe sunucusu acik. Programi tamamen kapatin, sonra guncellemeyi yeniden calistirin. Tarayiciyi kapatmak tek basina yeterli degildir." }
    $files = @('app.py','templates\day_close.html')
    foreach ($relative in $files) {
        if (!(Test-Path -LiteralPath (Join-Path $base $relative))) { throw "Guncelleme dosyasi eksik: $relative" }
        if (!(Test-Path -LiteralPath (Join-Path $Target $relative))) { throw "Mevcut kurulum dosyasi eksik: $relative" }
    }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $backup = Join-Path $Target ("backups\GUNCELLEME_V10_6_1_" + $stamp + '_' + [guid]::NewGuid().ToString('N').Substring(0,8))
    [void](New-Item -ItemType Directory -Path $backup -Force)
    $backupFiles = $files + @('KampusArena_Muhasebe.db','KampusArena_Muhasebe.db-wal','KampusArena_Muhasebe.db-shm','KampusArena_Muhasebe.xlsx','admin_excel_secret.dat','runtime\session.key')
    foreach ($relative in $backupFiles) {
        $from = Join-Path $Target $relative
        if (Test-Path -LiteralPath $from) {
            $dest = Join-Path $backup $relative
            [void](New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force)
            Copy-Item -LiteralPath $from -Destination $dest -ErrorAction Stop
        }
    }
    $database = Join-Path $Target 'KampusArena_Muhasebe.db'
    $before = (Get-FileHash -LiteralPath $database -Algorithm SHA256).Hash
    try {
        foreach ($relative in $files) { Copy-Item -LiteralPath (Join-Path $base $relative) -Destination (Join-Path $Target $relative) -Force -ErrorAction Stop }
        $after = (Get-FileHash -LiteralPath $database -Algorithm SHA256).Hash
        if ($before -ne $after) { throw "Guncelleme sirasinda veritabani degisti. Programin tamamen kapali oldugunu kontrol edin." }
    } catch {
        foreach ($relative in $files) { Copy-Item -LiteralPath (Join-Path $backup $relative) -Destination (Join-Path $Target $relative) -Force -ErrorAction Stop }
        throw
    }
    Write-Host "GUNCELLEME TAMAMLANDI. Veritabani ve anahtarlar korundu." -ForegroundColor Green
    Write-Host "Yedek: $backup"
    Write-Host "Mevcut program klasorundeki BASLAT.bat ile acin. Gun kilidi ekraninda Toplu gun kilidi acma bolumunu kullanin."
} catch {
    Write-Host ("GUNCELLEME TAMAMLANAMADI: " + $_.Exception.Message) -ForegroundColor Red
    if ($backup) { Write-Host "Yedek klasoru: $backup" }
    exit 1
}
